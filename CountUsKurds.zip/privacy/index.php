<?php
declare(strict_types=1);

require_once __DIR__ . '/../public/privacy/index.php';
